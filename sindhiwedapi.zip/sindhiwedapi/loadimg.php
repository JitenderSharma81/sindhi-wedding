<?php
include 'config/DBConfig.php';
 
// Create connection

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);
 
if ($conn->connect_error) {
 
 die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['but_upload'])){
 
  $name = $_FILES['file']['name'];
  $target_dir = "images/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
 
    // Upload file
    move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
    echo " name = ".$name."<br>  target dir  =  ".$target_dir."<br>    target file  = ".$target_file."<br> img file type = ".$imageFileType;
    echo "<br>uploaded";
    // Insert record
     $query = "insert into images(name) values('".$name."')";
     mysqli_query($conn,$query);
  
    
  }
 
}
$conn->close();
?>

<form method="post" action="" enctype='multipart/form-data'>
  <input type='file' name='file' />
  <input type='submit' value='Save name' name='but_upload'>
</form>
