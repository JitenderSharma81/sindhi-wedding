<?php
 
// Importing DBConfig.php file.
include '../config/DBConfig.php';
 
// Connecting to MySQL Database.
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 
 // creating unique id for each user.
 $Id =  uniqid();
 // Populate Student name from JSON $obj array and store into $S_Name.
 $Name = $obj['Name'];
 // Populate Speaker name from JSON $obj array and store into $S_Name.
 $Speaker = $obj['Speaker'];
 
 // Populate Student Class from JSON $obj array and store into $S_Class.
 $Image = $obj['Image'];
 
 // Populate Student Phone Number from JSON $obj array and store into $S_Phone_Number.
 $StartDate = $obj['StartDate'];
 
 // Populate Email from JSON $obj array and store into $Description.
 $Description = $obj['Description'];
 
 // Populate Email from JSON $obj array and store into $Description.
 $EndDate = $obj['EndDate'];
 
 // Creating SQL query and insert the record into MySQL database table.
 $Sql_Query = "insert into events(Id,Name,Speaker,Image,Description,StartDate,EndDate) values('$Id','$Name','$Speaker','$Image','$Description','$StartDate','$EndDate')";
 
 
 if(mysqli_query($con,$Sql_Query) or die(mysqli_error($con))){
 
 // If the record inserted successfully then show the message.
// $MSG = 'Record Inserted' ;
$MSG = array('result' => 'Record Inserted', 'Id' => $Id);

 
// Converting the message into JSON format.
$json = json_encode($MSG);
 
// Echo the message.
 echo $json ;
 
 }
 else{
 
 echo 'Not Inserted Try Again.';
 
 }
 mysqli_close($con);
?>