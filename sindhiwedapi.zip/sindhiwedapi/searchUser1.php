<?php
include 'config/DBConfig.php';
 
// Create connection

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);
 
if ($conn->connect_error) {
 
 die("Connection failed: " . $conn->connect_error);
} 

//if(isset($_POST['but_upload'])){
 
  
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
// Populate User email from JSON $obj array and store into $email.
$Name = $obj['Name'];
$minHeight = $obj['minHeight'];
$maxHeight = $obj['maxHeight'];
$Education = $obj['Education'];
$Mobile = $obj['Mobile'];
 
// $Sql_Query = "select * from admin where Mobile = '$phone' and Password = '$password' ";
 
$sql ="SELECT * 
FROM register
inner join userprofilestep1  on register.Id = userprofilestep1.RegisterId 
where register.Name ='$Name'
OR userprofilestep1.Height BETWEEN '$minHeight' AND '$maxHeight'
OR userprofilestep1.Education = '$Education'
OR register.Mobile = '$Mobile'";
// echo "conn".$Name." ".$Height;
 
$result = $conn->query($sql);
// echo $result;
if ($result->num_rows >0) {
 
 
 while($row[] = $result->fetch_assoc()) {
 
 $item = $row;
 
 $json = json_encode($item);
 
 }
 
}
 else {
 echo "No Results Found.";
}
echo $json;

// }
$conn->close();
?>
