<?php
 
// Importing DBConfig.php file.
// include 'DBConfig.php';
include 'config/DBConfig.php'; 
// Connecting to MySQL Database.
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 
 // creating unique id for each user.
 $Id =  uniqid();
 // Populate Student name from JSON $obj array and store into $S_Name.
 $Name = $obj['name'];
// $Name = 'aaaaaaa';
 // Populate Student Class from JSON $obj array and store into $S_Class.
//  $Email = $obj['email'];
$Email = 'aa@ss.cc';
 
 // Populate Student Phone Number from JSON $obj array and store into $S_Phone_Number.
//  $Password = md5($obj['password']);
$Password = md5('sdfsfs');
 // Populate Email from JSON $obj array and store into $S_Email.
//  $Mobile = $obj['mobile'];
$Mobile = 12345678;
 // Creating SQL query and insert the record into MySQL database table.
 $Sql_Query = "insert into register (Id,Name,Email,Mobile,Password) values ('$Id','$Name','$Email','$Mobile','$Password')";
 
 
 if(mysqli_query($con,$Sql_Query) or die(mysqli_error($con))){
 
 // If the record inserted successfully then show the message.
// $MSG = 'Record Inserted' ;
$MSG = array('result' => 'Record Inserted', 'Id' => $Id);

 
// Converting the message into JSON format.
$json = json_encode($MSG);
 
// Echo the message.
 echo $json ;
 
 }
 else{
 
 echo 'Not Inserted Try Again.';
 
 }
 mysqli_close($con);
?>