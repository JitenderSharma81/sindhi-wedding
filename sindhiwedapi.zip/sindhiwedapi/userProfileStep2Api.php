<?php
 
// Importing DBConfig.php file.
include 'config/DBConfig.php';
 
// Connecting to MySQL Database.
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
// echo'connected db hurrey';

 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 
 // creating unique id for each user.
 $Id =  uniqid();
 // Populate Student name from JSON $obj array and store into $S_Name.
 
 $UserID = $obj['userID'];  // retriving registered user Id.
 $FathersName= $obj['FathersName'];
 $FamilyType = $obj['FamilyType'];
 $FamilyStatus = $obj['FamilyStatus'];
 $Cast = $obj['Cast'];
 $Gothram = $obj['Gothram'];
 $Description = $obj['Description'];

 // Creating SQL query and insert the record into MySQL database table.
 $Sql_Query = "insert into userprofilestep2 (Id,RegisterID,FathersName,FamilyType,FamilyStatus,Cast,Gothram,Description) values ('$Id','$UserID','$FathersName','$FamilyType','$FamilyStatus','$Cast','$Gothram','$Description')";
 
 
 if(mysqli_query($con,$Sql_Query) or die(mysqli_error($con))){
 
 // If the record inserted successfully then show the message.
// $MSG = 'Record Inserted' ;
$MSG = array('result' => 'Record Inserted', 'Id' => $Id);

 
// Converting the message into JSON format.
$json = json_encode($MSG);
 
// Echo the message.
 echo $json ;
 
 } 
 else{
 
 echo 'Not Inserted Try Again.'.$Sql_Query;
 
 }

 mysqli_close($con);
?>