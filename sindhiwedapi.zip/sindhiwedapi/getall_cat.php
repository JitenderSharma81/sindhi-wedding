
	<?php
	
	$url = "http://192.168.43.152:5000/api/category/foradmin/";
		$client = curl_init($url);
		curl_setopt($client,CURLOPT_RETURNTRANSFER,true);
		$response = curl_exec($client);		
		$result = json_decode($response);
		
		print_r($result); 
		/* foreach($result as $value){
		
		 echo $array_name = $value->Id; 
		 echo $array_name = $value->UserName; 
		 echo $array_name = $value->Mobile; 
		 echo $array_name = $value->Email; 
		*/
	?>
  <?php
		
?>
