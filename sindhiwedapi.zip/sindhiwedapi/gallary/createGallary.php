<?php
 
// Importing DBConfig.php file.
include '../config/DBConfig.php';
 
// Connecting to MySQL Database.
 $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
 
 // creating unique id for each user.
 $Id =  uniqid();
 // Populate Image_1 from JSON $obj array and store into $Image_1.
 $Image_1 = $obj['Image_1'];
 // Populate Image_2 from JSON $obj array and store into $Image_2.
 // $Image_2 = $obj['Image_2'];
 
 // Populate Image_3 from JSON $obj array and store into $Image_3.
 // $Image_3 = $obj['Image_3'];
 
 // Populate EventID Number from JSON $obj array and store into $EventID.
 $EventID = $obj['EventID'];
 
 // Creating SQL query and insert the record into MySQL database table.
 $Sql_Query = "insert into gallary(Id,EventID,Image_1)
 values('$Id','$EventID','$Image_1')";
 
 
 if(mysqli_query($con,$Sql_Query) or die(mysqli_error($con))){
 
 // If the record inserted successfully then show the message.
// $MSG = 'Record Inserted' ;
$MSG = array('result' => 'Record Inserted', 'Id' => $Id);

 
// Converting the message into JSON format.
$json = json_encode($MSG);
 
// Echo the message.
 echo $json ;
 
 }
 else{
 
 echo 'Not Inserted Try Again.';
 
 }
 mysqli_close($con);
?>