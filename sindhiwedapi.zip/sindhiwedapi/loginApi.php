<?php
 
// Importing DBConfig.php file.
include 'config/DBConfig.php';
 
 
// Create connection

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);
 
if ($conn->connect_error) {
 
 die("Connection failed: " . $conn->connect_error);
} 

 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
// Populate User email from JSON $obj array and store into $email.
$phone = $obj['phone'];
// $phone = '1234567899';
 // $email = 'testadmin@gmail.com';
// Populate Password from JSON $obj array and store into $password.
$password =  md5($obj['password']);
 
 // $password = 'cc03e747a6afbbcbf8be7668acfebee5';
//Applying User Login query with email and password match.
$Sql_Query = "select * from admin where Mobile = '$phone' and Password = '$password' ";
 
// Executing SQL Query.
$check = mysqli_fetch_array(mysqli_query($conn,$Sql_Query));
 

if(isset($check)){
 
 $SuccessLoginMsg = 'Data Matched';
 
 // Converting the message into JSON format.
$SuccessLoginJson = json_encode($SuccessLoginMsg);
 
// Echo the message.
 echo $SuccessLoginJson ; 
 
 }
 
 else{
 
 // If the record inserted successfully then show the message.
$InvalidMSG = 'Invalid Username or Password Try Again.';
 
// Converting the message into JSON format.
$InvalidMSGJSon = json_encode($InvalidMSG);
 
// Echo the message.
 echo $InvalidMSGJSon ;
 
 }
 
 mysqli_close($conn);
?>