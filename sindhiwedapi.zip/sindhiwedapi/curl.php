<?php
	
	define("api_url", "http://localhost/loginApi.php");
	
	
	  function testHTTPPost() {
        $requestArr = array("addPerson" => array("foo", "bar"));
        $url        = "http://localhost/loginApi.php";
        // $this->assertEquals(HTTPRequester::HTTPPost($url, $requestArr), '[{"error":false}]');
		$response = HTTPRequester::HTTPPost($url, array("postParam" => "foobar"));

    }
	
	// getting list of all gym records from gym table.
	function getall_category(){
		$url = api_url."/gym";
		$client = curl_init($url);
		curl_setopt($client,CURLOPT_RETURNTRANSFER,true);
		$response = curl_exec($client);		
		$result = json_decode($response);
		return $result;
	}
	function add_category($name,$description){
		
		
		define('NAME',$name);
		define('DESCRIPTION',$description);
	
		//Set a user agent. This basically tells the server that we are using Chrome ;)
		define('USER_AGENT', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.2309.372 Safari/537.36');
		
		//Login action URL. Sometimes, this is the same URL as the login form.
		define('LOGIN_ACTION_URL', api_url);
		
		//An associative array that represents the required form fields.
		$postValues = array(
	
		'Name' => NAME,
		'Description' => DESCRIPTION,
		
		);
		
		//Initiate cURL.
		$curl = curl_init();
		
		//Set the URL where we want to send our POST request.
		curl_setopt($curl, CURLOPT_URL, LOGIN_ACTION_URL);
		
		//Tell cURL that we want to carry out a POST request.
		curl_setopt($curl, CURLOPT_POST, true);
		
		//Set our post fields / date (from the array above).
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($postValues));
		
		//We don't want any HTTPS errors.
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		
		//Sets the user agent. Some websites will attempt to block bot user agents.
		//Hence the reason I gave it a Chrome user agent.
		curl_setopt($curl, CURLOPT_USERAGENT, USER_AGENT);
		
		//Tells cURL to return the output once the request has been executed.
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		//Do we want to follow any redirects?
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
		
		//Check for errors!
		if(curl_errno($curl)){
			throw new Exception("Error occured=".curl_error($curl));
		}
		
		//Use the same user agent, just in case it is used by the server for session validation.
		curl_setopt($curl, CURLOPT_USERAGENT, USER_AGENT);
		
		//We don't want any HTTPS / SSL errors.
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		
		//Execute the POST request. 
		$response = curl_exec($curl);
		$result = json_decode($response);
		//print_r($result);
		return $result;
		
	}
	
	
	?>