<?php
include 'config/DBConfig.php';
 
// Create connection

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
$conn = new mysqli($HostName, $HostUser, $HostPass, $DatabaseName);
 
if ($conn->connect_error) {
 
 die("Connection failed: " . $conn->connect_error);
} 
 
 // Getting the received JSON into $json variable.
 $json = file_get_contents('php://input');
 
 // decoding the received JSON and store into $obj variable.
 $obj = json_decode($json,true);
 
// Populate User email from JSON $obj array and store into $email.
$Id = $obj['id'];

// fetching record from two tables - register and userprofilestep1 .
// $sql= "select Name,Education from register 
// inner join userprofilestep1  on register.Id = userprofilestep1.RegisterId where register.Id ='6071eb7c5013e'";

$sql ="SELECT * 
FROM register
inner join userprofilestep1  on register.Id = userprofilestep1.RegisterId 
where register.Name ='Kalu'
OR userprofilestep1.Height = '7.0'
OR userprofilestep1.Education = 'ba'
OR register.Mobile = '987654321'";


// $sql ="select 'register' OriginatingTable, Name
//   from register
//  where Name like '%Kalu%'
// union all
// select 'userprofilestep1', Height
//   from userprofilestep1
//  where City like '%Fff%'
// union all
// select 'userprofilestep2', FathersName
//   from userprofilestep2
//  where Gothram like '%abc%'";

$result = $conn->query($sql);

if ($result->num_rows >0) {
 
 
 while($row[] = $result->fetch_assoc()) {
 
 $item = $row;
 
 $json = json_encode($item);
 
 }
 
} else {
 echo "No Results Found.";
}
 echo $json;
$conn->close();
?>